module com.majesty.mfreelance {
    requires javafx.controls;
    requires javafx.fxml;
    requires mysql.connector.java;
    requires java.sql;


    opens com.majesty.mfreelance to javafx.fxml;
    exports com.majesty.mfreelance;
}