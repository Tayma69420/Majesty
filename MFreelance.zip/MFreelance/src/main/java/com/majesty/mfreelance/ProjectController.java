package com.majesty.mfreelance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProjectController implements Initializable {
    Connection con = null;
    PreparedStatement st = null;
    ResultSet rs = null;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnUpdate;

    @FXML
    private TextField tDate;

    @FXML
    private TextField tDescription;

    @FXML
    private TextField tPrix;

    @FXML
    private TextField tTitre;
    @FXML
    private TableColumn<Project, Date> colDate;

    @FXML
    private TableColumn<Project, String> colDesc;

    @FXML
    private TableColumn<Project, Integer> colId;

    @FXML
    private TableColumn<Project, Double> colPrix;

    @FXML
    private TableColumn<Project, String> colTitre;

    @FXML
    private TableView<Project> table;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showProjects();

    }
    public ObservableList<Project> getProject(){
        ObservableList<Project> projects = FXCollections.observableArrayList();
        String query= "Select* from projet";
        con = DBConnexion.getCon();
        try {
            st = con.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()){
                Project project = new Project();
                st.setId_project(rs.getInt("id"));
                st.setTitre_project(rs.getString("titre"));
                st.setDesc_project(rs.getString("desc"));
                st.setDate_project(rs.getDate("date"));
                st.setPrice_project(rs.getDouble("price"));
                project.add(st);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return projects;
    }
    public void showProjects(){
        ObservableList<Project> list =getProject();
        table.setItems(list);
        colId.setCellValueFactory(new PropertyValueFactory<Project, Integer>("id"));
        colTitre.setCellValueFactory(new PropertyValueFactory<Project, String>("titre"));
        colDesc.setCellValueFactory(new PropertyValueFactory<Project, String>("desc"));
        colDate.setCellValueFactory(new PropertyValueFactory<Project, Date>("date"));
        colPrix.setCellValueFactory(new PropertyValueFactory<Project, Double>("price"));

    }

    @FXML
    void clearProject(ActionEvent event) {

    }

    @FXML
    void createProject(ActionEvent event) {

            String insert = "INSERT INTO projet (titre_project, desc_project, date_project, price_project) VALUES(?,?,?)";
            con = DBConnexion.getCon();
            try {
                st = con.prepareStatement(insert);
                st.setString(1, tTitre.getText());
                st.setString(2, tDescription.getText());
                st.setDate(2, java.sql.Date.valueOf(tDate.getText()));
                st.setDouble(2, Double.parseDouble(tPrix.getText()));
                st.executeUpdate();
                showProjects();
            } catch (SQLException ex) {
                Logger.getLogger(ProjectController.class.getName())
                        .log(Level.SEVERE, null, ex);
            }
        }


    @FXML
    void deleteProject(ActionEvent event) {
        con = DBConnexion.getCon();
        String delete = "DELETE FROM projet  where titre_project = ?";
        try {
            st = con.prepareStatement(delete);
            st.setString(1, String.valueOf(Integer.parseInt(tTitre.getText())));
            st.executeUpdate();
            showProjects();
        } catch (SQLException ex) {
            Logger.getLogger(ProjectController.class.getName())
                    .log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    void updateProject(ActionEvent event) {
        con = DBConnexion.getCon();
        String update
                = "UPDATE projet SET titre_project =?,desc_project = ?,date_project =? where id =?,price_project =? where id =?";
        try {
            st = con.prepareStatement(update);
            st.setString(1, tTitre.getText());
            st.setString(2, tDescription.getText());
            st.setDate(2, java.sql.Date.valueOf(tDate.getText()));
            st.setDouble(2, Double.parseDouble(tPrix.getText()));
            st.executeUpdate();
            showProjects();
        } catch (SQLException ex) {
            Logger.getLogger(ProjectController.class.getName())
                    .log(Level.SEVERE, null, ex);
        }

    }


}
