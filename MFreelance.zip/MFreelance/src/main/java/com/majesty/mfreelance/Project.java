package com.majesty.mfreelance;

import java.util.Date;

public class Project {
    private int id_project;
    private String titre_project;
    private String desc_project;
    private Date date_project;
    private double price_project;

    public Project(){

    }

    public Project(int id_project, String titre_project, String desc_project, Date date_project, double price_project) {
        this.id_project = id_project;
        this.titre_project = titre_project;
        this.desc_project = desc_project;
        this.date_project = date_project;
        this.price_project = price_project;
    }

    public int getId_project() {
        return id_project;
    }

    public void setId_project(int id_project) {
        this.id_project = id_project;
    }

    public String getTitre_project() {
        return titre_project;
    }

    public void setTitre_project(String titre_project) {
        this.titre_project = titre_project;
    }

    public String getDesc_project() {
        return desc_project;
    }

    public void setDesc_project(String desc_project) {
        this.desc_project = desc_project;
    }

    public Date getDate_project() {
        return date_project;
    }

    public void setDate_project(Date date_project) {
        this.date_project = date_project;
    }

    public double getPrice_project() {
        return price_project;
    }

    public void setPrice_project(double price_project) {
        this.price_project = price_project;
    }

    @Override
    public String toString() {
        return "Project{" +
                "id_project=" + id_project +
                ", titre_project='" + titre_project + '\'' +
                ", desc_project='" + desc_project + '\'' +
                ", date_project=" + date_project +
                ", price_project=" + price_project +
                '}';
    }
}
